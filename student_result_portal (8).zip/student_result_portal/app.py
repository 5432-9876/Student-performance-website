from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from pathlib import Path
import random

app = Flask(__name__)
app.config["SECRET_KEY"] = "change-this-secret-key-before-deployment"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///students.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

SUBJECTS = [
    ("BEC", "Basics of Electronic and Communication", "Lab Viva"),
    ("FEE", "Fundamental of Electrical Engineering", "Lab Viva"),
    ("QP", "Quantum Physics", "Lab Viva"),
    ("CP", "Computer Programming", "Lab Viva"),
    ("MATH", "Mathematics", "Class Test"),
]

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    roll_no = db.Column(db.String(40), unique=True, nullable=False)
    end_sem = db.Column(db.Text, nullable=False)   # JSON-like comma-separated values
    mid_sem = db.Column(db.Text, nullable=False)
    practical = db.Column(db.Text, nullable=False)

    def marks(self):
        return {
            code: (int(self.end_sem.split(",")[i]), int(self.mid_sem.split(",")[i]),
                   int(self.practical.split(",")[i]))
            for i, (code, _, _) in enumerate(SUBJECTS)
        }

    def subject_results(self):
        results = []
        for code, title, component in SUBJECTS:
            end, mid, practical = self.marks()[code]
            total = end + mid + practical
            results.append({
                "code": code, "title": title, "component": component,
                "end": end, "mid": mid, "practical": practical,
                "total": total, "grade": grade_for(total)
            })
        return results

    @property
    def grand_total(self):
        return sum(x["total"] for x in self.subject_results())

    @property
    def percentage(self):
        return self.grand_total / (len(SUBJECTS) * 100) * 100

def grade_for(total):
    # Boundary interpretation: 90 is B; A begins above 90.
    if total > 90: return "A"
    if total >= 80: return "B"
    if total >= 70: return "C"
    if total >= 60: return "D"
    if total >= 50: return "E"
    return "F"

def leaderboard():
    students = Student.query.all()
    students.sort(key=lambda s: (-s.grand_total, s.name.lower(), s.roll_no))
    return students

def seed_demo_data():
    if Student.query.count() >= 50:
        return
    random.seed(42)
    names = [
        "Aarav Sharma","Aditi Verma","Aditya Singh","Ananya Gupta","Arjun Mehta",
        "Diya Joshi","Ishaan Kapoor","Kavya Nair","Krishna Patel","Meera Shah",
        "Rohan Das","Saanvi Rao","Vivaan Khanna","Ira Malhotra","Reyansh Jain",
        "Myra Bansal","Advait Mishra","Anika Sethi","Kabir Arora","Pari Saxena",
        "Dhruv Yadav","Sara Khan","Atharv Roy","Navya Iyer","Ayaan Chawla",
        "Kiara Menon","Vihaan Ghosh","Riya Thakur","Neil Dutta","Tara Kulkarni",
        "Om Prakash","Ishita Sen","Manav Bhatia","Aarohi Desai","Yash Tiwari",
        "Prisha Reddy","Dev Malhotra","Aanya Bose","Samar Gill","Nisha Pandey",
        "Rahul Kumar","Simran Kaur","Kunal Sinha","Tanvi Agarwal","Harsh Vora",
        "Pooja Rawat","Siddharth Paul","Mahi Choudhary","Ritvik Anand","Sneha Pillai"
    ]
    for i, name in enumerate(names, 1):
        ends, mids, practicals = [], [], []
        for _ in SUBJECTS:
            ends.append(random.randint(25, 50))
            mids.append(random.randint(9, 20))
            practicals.append(random.randint(14, 30))
        db.session.add(Student(
            name=name, roll_no=f"STU{i:03d}",
            end_sem=",".join(map(str, ends)),
            mid_sem=",".join(map(str, mids)),
            practical=",".join(map(str, practicals))
        ))
    db.session.commit()

@app.route("/")
def index():
    students = leaderboard()
    count = len(students)
    average = round(sum(s.grand_total for s in students) / count, 2) if count else 0
    topper = students[0] if students else None
    return render_template("index.html", students=students, count=count,
                           average=average, topper=topper, subjects=SUBJECTS)

@app.route("/add", methods=["GET", "POST"])
def add_student():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        roll = request.form.get("roll_no", "").strip()
        if not name or not roll:
            flash("Please enter both student name and roll number.", "error")
            return redirect(url_for("add_student"))
        if Student.query.filter_by(roll_no=roll).first():
            flash("That roll number already exists. Use a unique roll number.", "error")
            return redirect(url_for("add_student"))
        ends, mids, practicals = [], [], []
        try:
            for code, title, component in SUBJECTS:
                end = int(request.form[f"end_{code}"])
                mid = int(request.form[f"mid_{code}"])
                practical = int(request.form[f"practical_{code}"])
                if not (0 <= end <= 50 and 0 <= mid <= 20 and 0 <= practical <= 30):
                    raise ValueError("Marks are outside the allowed range.")
                ends.append(end); mids.append(mid); practicals.append(practical)
        except (ValueError, KeyError):
            flash("Enter valid marks: End Sem 0–50, Mid Sem 0–20, Lab Viva/Class Test 0–30.", "error")
            return redirect(url_for("add_student"))
        student = Student(name=name, roll_no=roll,
                          end_sem=",".join(map(str, ends)),
                          mid_sem=",".join(map(str, mids)),
                          practical=",".join(map(str, practicals)))
        db.session.add(student); db.session.commit()
        flash("Student result saved successfully.", "success")
        return redirect(url_for("report", roll_no=roll))
    return render_template("add_student.html", subjects=SUBJECTS)

@app.route("/report", methods=["GET", "POST"])
def find_report():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        roll = request.form.get("roll_no", "").strip()
        student = Student.query.filter(func.lower(Student.roll_no) == roll.lower()).first()
        if student and student.name.lower() == name.lower():
            return redirect(url_for("report", roll_no=student.roll_no))
        flash("No exact match found. Check the student's name and roll number.", "error")
    return render_template("find_report.html")

@app.route("/report/<roll_no>")
def report(roll_no):
    student = Student.query.filter_by(roll_no=roll_no).first_or_404()
    ranked = leaderboard()
    rank = next(i for i, s in enumerate(ranked, 1) if s.id == student.id)
    return render_template("report.html", student=student, rank=rank,
                           class_size=len(ranked), results=student.subject_results())

@app.route("/leaderboard")
def leaderboard_page():
    return render_template("leaderboard.html", students=leaderboard())

with app.app_context():
    db.create_all()
    seed_demo_data()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
