# Student Result Management Portal

A responsive Flask + SQLite web app for entering student marks, calculating subject grades, ranking the class, showing the topper and class average, and printing individual report cards.

## Included
- Responsive HTML/CSS interface for mobile, tablet and desktop
- Flask backend and SQLite database
- 50 clearly synthetic demo students (STU001–STU050)
- Five subjects: Basics of Electronic and Communication, Fundamental of Electrical Engineering, Quantum Physics, Computer Programming, Mathematics
- Marks per subject: End Sem / 50, Mid Sem / 20, Lab Viva or Class Test / 30
- Subject grades: >90 A, 80–90 B, 70–<80 C, 60–<70 D, 50–<60 E, <50 F
- Class ranking by total marks out of 500, class average and topper
- Report-card lookup requiring exact name + roll number
- Print / Save as PDF report card

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Run:
   ```bash
   python -m venv .venv
   # Windows:
   .venv\Scripts\activate
   # macOS/Linux:
   source .venv/bin/activate
   pip install -r requirements.txt
   python app.py
   ```
4. Open http://127.0.0.1:5000

The SQLite database is created automatically at first run. The 50 demo records are inserted only when the database has fewer than 50 students.

## Publish with a public URL (Render)
1. Create a GitHub repository and upload this project.
2. Sign in to Render and choose **New → Web Service**; connect the repository.
3. Render detects `render.yaml`, or enter build command `pip install -r requirements.txt` and start command `gunicorn app:app`.
4. Deploy. Render will provide a public `https://...onrender.com` URL.

## Important before real institutional use
- Replace demo data with verified student data.
- Change `SECRET_KEY` to a long random secret and configure it as an environment variable.
- SQLite is suitable for a demo/small deployment. For production, use managed PostgreSQL and persistent storage.
- Add authentication/role permissions and backups before entering real student records.
- The requested grading bands overlap at 90 in the wording. This implementation treats 90 as B and A as strictly greater than 90.
- "Relative grading" here means class ranking by aggregate marks; grade letters remain the fixed thresholds supplied in the request. If you want statistical relative grades (based on class distribution), the grade policy needs to be changed.
